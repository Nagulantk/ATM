package View;

public interface Process {
      Enum getProcess(String process);
}
