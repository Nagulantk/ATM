package View;

import Model.Accounts;

public interface BankAccountGeneration {

     Accounts accountGeneration();
}
