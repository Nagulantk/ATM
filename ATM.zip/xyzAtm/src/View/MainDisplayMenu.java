package View;

public class MainDisplayMenu implements DisplayMenu{
    public  void displayMenu()
    {
        System.out.println("Enter the action to be performed:");
        System.out.println("Banking");
        System.out.println("ATM");
        System.out.println("Swipe");
        System.out.println("Exit");
    }

}
