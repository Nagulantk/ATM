package View;

import Model.CreditCard;

public interface CreditCardDetails {
    void displayDetails(CreditCard card);
}
