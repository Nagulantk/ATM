package View;

public interface DisplayMenu {
    void displayMenu();
}
