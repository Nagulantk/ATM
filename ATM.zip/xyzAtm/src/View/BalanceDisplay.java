package View;

import Model.Accounts;

public interface BalanceDisplay {
    void balanceDisplay(Accounts account);
}
