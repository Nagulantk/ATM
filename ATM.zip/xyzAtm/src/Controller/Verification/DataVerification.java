package Controller.Verification;

import Model.Card;

public interface DataVerification {
    long verification(Card.CardType cardType);

}
