package Controller.Verification;

import java.time.LocalDate;


public interface DateVerification {
   LocalDate verifyDate();
}
