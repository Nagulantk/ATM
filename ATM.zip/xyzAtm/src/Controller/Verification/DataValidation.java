package Controller.Verification;

public interface DataValidation {
   long validation(String name);
}
