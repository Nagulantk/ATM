package Controller.ATM;

import Model.CreditCard;

public interface CreditCardDueBalance {
 CreditCard creditCardDueBalance();
}
