package Controller.ATM;

import Model.Accounts;

public interface AmountWithdraw {
    Accounts withdraw();
}
