package Controller.ATM;

import Model.CreditCard;

public interface CreditCardAmountWithdraw {
     CreditCard creditCardWithdraw();
}
