package Controller.ATM;

public interface AmountDeposit {
   void deposit();
}
