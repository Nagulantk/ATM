package Controller.ATM;

import Model.Accounts;

public interface Balance {
     Accounts getBalance();
}
