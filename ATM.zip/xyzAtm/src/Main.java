import Controller.MainMenu;

public class Main {

    public static void main(String[] args) {
        MainMenu main=new MainMenu();
        main.mainWorking();
    }
}
